﻿namespace Mohanad_MS539_Assignment_2._1_GUIS
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.Decimal = new System.Windows.Forms.TextBox();
            this.RoundButton = new System.Windows.Forms.Button();
            this.progressBar = new System.Windows.Forms.ProgressBar();
            this.label1 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.button2 = new System.Windows.Forms.Button();
            this.writtenText = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.readButton = new System.Windows.Forms.Button();
            this.LabelRead = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(196, 179);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(216, 128);
            this.button1.TabIndex = 0;
            this.button1.Text = "Display Random Text";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(239, 142);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(112, 20);
            this.linkLabel1.TabIndex = 1;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Apple Website";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(54, 452);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(325, 26);
            this.dateTimePicker1.TabIndex = 2;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(54, 112);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(43, 24);
            this.radioButton1.TabIndex = 3;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "0";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(54, 168);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(52, 24);
            this.radioButton2.TabIndex = 4;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "10";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(35, 60);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(253, 26);
            this.textBox1.TabIndex = 5;
            this.textBox1.Text = "What is 5 + 5?";
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // Decimal
            // 
            this.Decimal.Location = new System.Drawing.Point(54, 266);
            this.Decimal.Name = "Decimal";
            this.Decimal.Size = new System.Drawing.Size(100, 26);
            this.Decimal.TabIndex = 6;
            this.Decimal.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // RoundButton
            // 
            this.RoundButton.Location = new System.Drawing.Point(26, 330);
            this.RoundButton.Name = "RoundButton";
            this.RoundButton.Size = new System.Drawing.Size(173, 79);
            this.RoundButton.TabIndex = 7;
            this.RoundButton.Text = "Click to Round";
            this.RoundButton.UseVisualStyleBackColor = true;
            this.RoundButton.Click += new System.EventHandler(this.RoundButton_Click);
            // 
            // progressBar
            // 
            this.progressBar.Location = new System.Drawing.Point(985, 45);
            this.progressBar.Name = "progressBar";
            this.progressBar.Size = new System.Drawing.Size(100, 23);
            this.progressBar.TabIndex = 9;
            this.progressBar.Click += new System.EventHandler(this.progressBar2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(1002, 80);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 20);
            this.label1.TabIndex = 10;
            this.label1.Text = "5 X 5 = ?";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(996, 122);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(53, 24);
            this.checkBox1.TabIndex = 11;
            this.checkBox1.Text = "10";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(985, 169);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(53, 24);
            this.checkBox2.TabIndex = 12;
            this.checkBox2.Text = "25";
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(300, 518);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(295, 162);
            this.button2.TabIndex = 13;
            this.button2.Text = "Click to Open Second Form";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // writtenText
            // 
            this.writtenText.Location = new System.Drawing.Point(752, 383);
            this.writtenText.Name = "writtenText";
            this.writtenText.Size = new System.Drawing.Size(274, 26);
            this.writtenText.TabIndex = 14;
            this.writtenText.TextChanged += new System.EventHandler(this.writtenText_TextChanged);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(656, 452);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(193, 118);
            this.button4.TabIndex = 15;
            this.button4.Text = "Write to File";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // readButton
            // 
            this.readButton.Location = new System.Drawing.Point(890, 444);
            this.readButton.Name = "readButton";
            this.readButton.Size = new System.Drawing.Size(184, 134);
            this.readButton.TabIndex = 16;
            this.readButton.Text = "Read to File";
            this.readButton.UseVisualStyleBackColor = true;
            this.readButton.Click += new System.EventHandler(this.button5_Click);
            // 
            // LabelRead
            // 
            this.LabelRead.AutoSize = true;
            this.LabelRead.Location = new System.Drawing.Point(759, 336);
            this.LabelRead.Name = "LabelRead";
            this.LabelRead.Size = new System.Drawing.Size(251, 20);
            this.LabelRead.TabIndex = 17;
            this.LabelRead.Text = "Click below to read or write to a file";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(608, 138);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(254, 91);
            this.button3.TabIndex = 18;
            this.button3.Text = "Click to Generate a Random Number";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Coral;
            this.BackgroundImage = global::Mohanad_MS539_Assignment_2._1_GUIS.Properties.Resources.images;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(1200, 724);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.LabelRead);
            this.Controls.Add(this.readButton);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.writtenText);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.checkBox2);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.progressBar);
            this.Controls.Add(this.RoundButton);
            this.Controls.Add(this.Decimal);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.button1);
            this.ForeColor = System.Drawing.Color.DarkCyan;
            this.Name = "Form1";
            this.Text = "Mohanad GUI MS539 Assignment 4.1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox Decimal;
        private System.Windows.Forms.Button RoundButton;
        private System.Windows.Forms.ProgressBar progressBar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox writtenText;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button readButton;
        private System.Windows.Forms.Label LabelRead;
        private System.Windows.Forms.Button button3;
    }
}

