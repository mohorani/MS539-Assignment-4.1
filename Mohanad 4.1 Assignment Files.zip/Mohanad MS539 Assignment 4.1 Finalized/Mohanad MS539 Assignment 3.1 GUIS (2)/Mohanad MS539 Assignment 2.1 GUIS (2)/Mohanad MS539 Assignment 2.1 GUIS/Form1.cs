﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Security.Cryptography;
using System.Xml;


namespace Mohanad_MS539_Assignment_2._1_GUIS
{

    //Mohanad Horani MS539 Assignment 4.1 Final Project 

    public partial class Form1 : Form
    {
        decimal value;
        string textFile = "finalresults.txt";
        public Form1()
        {
            InitializeComponent();
        }

        //loads first form
        private void Form1_Load(object sender, EventArgs e)
        {

        }
        //sample button
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                MessageBox.Show("Button clicked successfully");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error!" + ex);
            }





        }
        //redirects user to apple.com website
        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

            {
                linkLabel1.LinkVisited = true;
                System.Diagnostics.Process.Start("http://apple.com");

            }



        }
        //shows the user today's date
        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

            MessageBox.Show("Today is....");
        }
        //if this option is selected then informs user that they are incorrect
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                MessageBox.Show("That is incorrect.");
            }
            else if (radioButton2.Checked)
                MessageBox.Show("That is correct! Congratulations!");
        }

        //math quiz question
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("What is 5 plus 5 equal to?");
        }
        //if this option is selected then informs user that they are correct.
        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2.Checked)
            {
                MessageBox.Show("That is correct! Congratulations!");
            }
            else if (radioButton1.Checked)
                MessageBox.Show("That is incorrect. Try again.");
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
        //rounds number to one decimal place
        private void RoundButton_Click(object sender, EventArgs e)
        {
            if (decimal.TryParse(Decimal.Text, out value))
            {
                value = decimal.Round(value, 1, MidpointRounding.AwayFromZero);
                Decimal.Text = value.ToString();
            }
        }
        //progress bar example
        private void progressBar2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Progress Bar Clicked");
        }
        //math quiz question
        private void label1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Which of the following is 5X5 equal to?");
        }
        
        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            MessageBox.Show("That is correct!");
        }
        
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            MessageBox.Show("That is incorrect!");
        }
        //displays second form
        private void button2_Click(object sender, EventArgs e)
        {
            Form f2 = new Form2();
            f2.Show();
        }
        //reads text file
        private void button5_Click(object sender, EventArgs e)
        {
            using (StreamReader reader = new StreamReader(textFile))
            {
                var fileContent = reader.ReadToEnd();
                writtenText.Text = fileContent;
                MessageBox.Show(fileContent);
            }
        }
        //writes text to file
        private void button4_Click(object sender, EventArgs e)
        {
            using (StreamWriter writer = File.AppendText(textFile))
            {
                writer.WriteLine(writtenText.Text);
            }
        }

        private void writtenText_TextChanged(object sender, EventArgs e)
        {

        }
        //generates a random number
        Random r = new Random();
        private void button3_Click(object sender, EventArgs e)
        {
            int randomNumber = r.Next(0, 1000);
            MessageBox.Show(randomNumber.ToString());
        }
    }
    }








